# ctfscoreboard
Scoreboard for Capture The Flag competitions, used by Universitas Kristen Satya Wacana

# MSG : versi ini merupakan versi terdahulu , mungkin dibutuhkan sedikit pembaruan.

Jika anda berminat untuk saya mengerjakan sebuah cms ctf sesuai dengan keinginan anda , anda bisa hubungin melalui facebook saya : 
http://facebook.com/eka.syahwan.id :)
